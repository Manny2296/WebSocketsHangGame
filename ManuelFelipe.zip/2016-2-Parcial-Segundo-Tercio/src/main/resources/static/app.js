var stompClient = null;
   
function sendRequest() {
      var gameid=$("#gameid").val();
    console.log("/hangmangames/hiddenwords/"+gameid);
    
    $.get( "/hangmangames/hiddenwords/"+gameid, 
        function( data ) {  
         
   
            $("#palabra").html("<h1>"+data+"</h1>");
        }    
    ).fail(
        function(data){
            alert(data["responseText"]);
        }
            
    ); 
  

}
function ingresarcaracter(){
        var gameid=$("#gameid").val();
     var char = document.getElementById('caracter').value;

    
    stompClient.send("/app/hangmangames/hiddenwords/",{},JSON.stringify({gameid:gameid,letr: char}));   
      agregarPalabra(char); 
}
var character = null;
function connect() {
    var socket = new SockJS('/stompendpoint');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        
        console.log('Connected: ' + frame);
        //var gameid=$("#gameid").val();
        
        stompClient.subscribe('/topic/hangmangames/hiddenwords/', function (data) {
            //subscriber action
         // var char = JSON.parse(data.body);
        
          sendRequest();     
      //alert("Hola");
          
         //alert("El cliente: "+ char.gameid + "Acaba de ingresar la letra  "+ char.letr);
           
          console.log("------> Suscribe : sendRequest(); ");
        });
        
        
    });
}
agregarPalabra = function(p){
    
  var gameid=$("#gameid").val();
    $.ajax({
            url: "http://localhost:8080/hangmangames/hiddenwords/update."+gameid,
            type: 'PUT',    
            data: JSON.stringify(p),
            contentType: "application/json",
            dataType: 'json',
            success: function(result) {
              //  alert("success agregada correctamente");
                console.log("Success");
            }
            });
}

function disconnect() {
    if (stompClient != null) {
        stompClient.disconnect();
    }
    setConnected(false);
    console.log("Disconnected");
}


$(document).ready(
        function () {
            connect();
            console.info('connecting to websockets');
        }
);
